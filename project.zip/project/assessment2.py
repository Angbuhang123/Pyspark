from pyspark.sql import SparkSession
from pyspark.sql.functions import when, col
from pyspark.ml.feature import StringIndexer, VectorAssembler, StandardScaler
from pyspark.ml.classification import DecisionTreeClassifier, LogisticRegression
from pyspark.ml.regression import LinearRegression
from pyspark.ml.evaluation import MulticlassClassificationEvaluator, RegressionEvaluator
from pyspark.ml import Pipeline

# Set up Spark session
spark = SparkSession.builder \
    .appName("BigData_Assessment2") \
    .config("spark.ui.showConsoleProgress", "false") \
    .getOrCreate()
spark.sparkContext.setLogLevel("ERROR")

# Load dataset
df = spark.read.csv("customer_purchases.csv", header=True, inferSchema=True)
df.printSchema()
df.show(5)

# Handle invalid data (0s)
df_clean = df.withColumn("Age", when(col("Age") == 0, None).otherwise(col("Age"))) \
             .withColumn("AnnualIncome", when(col("AnnualIncome") == 0, None).otherwise(col("AnnualIncome"))) \
             .withColumn("SpendingScore", when(col("SpendingScore") == 0, None).otherwise(col("SpendingScore"))) \
             .withColumn("TotalPurchases", when(col("TotalPurchases") == 0, None).otherwise(col("TotalPurchases"))) \
             .withColumn("PurchaseAmount", when(col("PurchaseAmount") == 0, None).otherwise(col("PurchaseAmount")))

# Filter rows with invalid PurchaseAmount (0s) before imputation
df_valid = df_clean.filter(col("PurchaseAmount").isNotNull())

# Compute medians for imputation
medians = df_valid.approxQuantile(
    ["Age", "AnnualIncome", "SpendingScore", "TotalPurchases"], [0.5], 0.01
)
median_dict = {
    "Age": medians[0][0],
    "AnnualIncome": medians[1][0],
    "SpendingScore": medians[2][0],
    "TotalPurchases": medians[3][0]
}

# Impute missing values
df_imputed = df_valid.fillna(median_dict)

# Final filter to ensure no invalid rows remain
df_final = df_imputed.filter(
    (col("Age") > 0) & (col("AnnualIncome") > 0) & (col("PurchaseAmount") > 0)
)
removed = df.count() - df_final.count()
print(f"Total rows removed: {removed}")

# Summary stats for PurchaseAmount
df_final.describe("PurchaseAmount").show()
median_purchase = df_final.approxQuantile("PurchaseAmount", [0.5], 0.01)[0]
print(f"Median PurchaseAmount: {median_purchase}")
df_final.selectExpr("variance(PurchaseAmount)", "stddev(PurchaseAmount)").show()

# Quartiles for TotalPurchases
quartiles = df_final.approxQuantile("TotalPurchases", [0.25, 0.5, 0.75], 0.01)
print(f"Quartiles for TotalPurchases: {quartiles}")

# Correlation
correlation = df_final.stat.corr("PurchaseAmount", "SpendingScore")
print(f"Pearson Correlation (PurchaseAmount vs SpendingScore): {correlation}")

# SQL Query
df_final.createOrReplaceTempView("customers")
sql_result = spark.sql("SELECT Age, SpendingScore FROM customers WHERE Age < 50 AND SpendingScore > 100")
if sql_result.count() == 0:
    print("No results found for Age < 50 and SpendingScore > 100.")
else:
    sql_result.show()

# Encode categorical variables
indexers = [
    StringIndexer(inputCol="Gender", outputCol="GenderIndex"),
    StringIndexer(inputCol="PurchaseCategory", outputCol="CategoryIndex")
]

# Assemble features for classification (exclude PurchaseAmount)
class_assembler = VectorAssembler(
    inputCols=["Age", "AnnualIncome", "SpendingScore", "TotalPurchases", "GenderIndex", "CategoryIndex"],
    outputCol="raw_features"
)
scaler = StandardScaler(inputCol="raw_features", outputCol="features", withStd=True, withMean=True)

# Split data for training and testing
train, test = df_final.randomSplit([0.8, 0.2], seed=42)

# Decision Tree Classifier
dt = DecisionTreeClassifier(labelCol="Outcome", featuresCol="features", maxDepth=5)
dt_pipeline = Pipeline(stages=indexers + [class_assembler, scaler, dt])
dt_model = dt_pipeline.fit(train)
dt_preds = dt_model.transform(test)
dt_eval = MulticlassClassificationEvaluator(labelCol="Outcome")
dt_acc = dt_eval.setMetricName("accuracy").evaluate(dt_preds)
dt_f1 = dt_eval.setMetricName("f1").evaluate(dt_preds)
dt_precision = dt_eval.setMetricName("weightedPrecision").evaluate(dt_preds)
dt_recall = dt_eval.setMetricName("weightedRecall").evaluate(dt_preds)
print(f"Decision Tree Accuracy: {dt_acc:.4f}")
print(f"Decision Tree F1-Score: {dt_f1:.4f}")
print(f"Decision Tree Precision: {dt_precision:.4f}")
print(f"Decision Tree Recall: {dt_recall:.4f}")

# Feature importance (for report)
dt_stage = dt_model.stages[-1]
feature_importance = dt_stage.featureImportances
features = ["Age", "AnnualIncome", "SpendingScore", "TotalPurchases", "GenderIndex", "CategoryIndex"]
print("Decision Tree Feature Importance:")
for i, imp in enumerate(feature_importance):
    print(f"{features[i]}: {imp:.4f}")

# Logistic Regression
lr = LogisticRegression(labelCol="Outcome", featuresCol="features", regParam=0.1, maxIter=100)
lr_pipeline = Pipeline(stages=indexers + [class_assembler, scaler, lr])
lr_model = lr_pipeline.fit(train)
lr_preds = lr_model.transform(test)
lr_acc = dt_eval.setMetricName("accuracy").evaluate(lr_preds)
lr_f1 = dt_eval.setMetricName("f1").evaluate(lr_preds)
lr_precision = dt_eval.setMetricName("weightedPrecision").evaluate(lr_preds)
lr_recall = dt_eval.setMetricName("weightedRecall").evaluate(lr_preds)
print(f"Logistic Regression Accuracy: {lr_acc:.4f}")
print(f"Logistic Regression F1-Score: {lr_f1:.4f}")
print(f"Logistic Regression Precision: {lr_precision:.4f}")
print(f"Logistic Regression Recall: {lr_recall:.4f}")

# Linear Regression (AnnualIncome only)
lin_assembler_single = VectorAssembler(inputCols=["AnnualIncome"], outputCol="single_feature")
lin_reg_single = LinearRegression(labelCol="PurchaseAmount", featuresCol="single_feature")
lin_pipeline_single = Pipeline(stages=[lin_assembler_single, lin_reg_single])
lin_model_single = lin_pipeline_single.fit(train)
lin_preds_single = lin_model_single.transform(test)
lin_eval = RegressionEvaluator(labelCol="PurchaseAmount")
lin_r2_single = lin_eval.setMetricName("r2").evaluate(lin_preds_single)
lin_rmse_single = lin_eval.setMetricName("rmse").evaluate(lin_preds_single)
print(f"Linear Regression (AnnualIncome only) R2: {lin_r2_single:.4f}, RMSE: {lin_rmse_single:.2f}")

# Linear Regression (multiple predictors)
lin_assembler = VectorAssembler(
    inputCols=["AnnualIncome", "Age", "SpendingScore", "TotalPurchases", "GenderIndex", "CategoryIndex"],
    outputCol="lin_features"
)
lin_scaler = StandardScaler(inputCol="lin_features", outputCol="scaled_features", withStd=True, withMean=True)
lin_reg = LinearRegression(labelCol="PurchaseAmount", featuresCol="scaled_features")
lin_pipeline = Pipeline(stages=indexers + [lin_assembler, lin_scaler, lin_reg])
lin_model = lin_pipeline.fit(train)
lin_preds = lin_model.transform(test)
lin_r2 = lin_eval.setMetricName("r2").evaluate(lin_preds)
lin_rmse = lin_eval.setMetricName("rmse").evaluate(lin_preds)
print(f"Linear Regression (Multiple Predictors) R2: {lin_r2:.4f}, RMSE: {lin_rmse:.2f}")

# End Spark session
spark.stop()